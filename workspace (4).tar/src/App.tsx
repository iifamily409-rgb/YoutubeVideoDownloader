import React, { useState, useRef, useCallback } from 'react';
import Header from './components/Header';
import URLInput from './components/URLInput';
import VideoInfoCard from './components/VideoInfoCard';
import QualityOptions from './components/QualityOptions';
import DownloadProgress from './components/DownloadProgress';
import Features from './components/Features';
import { VideoInfo, VideoFormat, DownloadState } from './types';
import { extractVideoId } from './utils/validators';
import { getMockVideoInfo, simulateDownload } from './utils/mockData';

function App() {
  const [isLoading, setIsLoading] = useState(false);
  const [videoInfo, setVideoInfo] = useState<VideoInfo | null>(null);
  const [error, setError] = useState<string>('');
  const [downloadState, setDownloadState] = useState<DownloadState>({
    status: 'idle',
    progress: 0,
    speed: '',
    eta: '',
    format: null,
  });

  const cancelDownloadRef = useRef<(() => void) | null>(null);

  const handleFetch = useCallback(async (url: string) => {
    setIsLoading(true);
    setError('');
    setVideoInfo(null);
    setDownloadState({ status: 'idle', progress: 0, speed: '', eta: '', format: null });

    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1500));

    const videoId = extractVideoId(url);
    if (!videoId) {
      setError('Could not extract video ID from URL');
      setIsLoading(false);
      return;
    }

    const info = getMockVideoInfo(videoId);
    if (!info) {
      setError('Video not found or is private/deleted');
      setIsLoading(false);
      return;
    }

    setVideoInfo(info);
    setIsLoading(false);
  }, []);

  const handleDownload = useCallback((format: VideoFormat) => {
    setDownloadState({
      status: 'preparing',
      progress: 0,
      speed: '',
      eta: '',
      format,
    });

    // Simulate preparation delay
    setTimeout(() => {
      setDownloadState(prev => ({ ...prev, status: 'downloading' }));

      const cancel = simulateDownload(
        (progress, speed, eta) => {
          setDownloadState(prev => ({
            ...prev,
            progress,
            speed,
            eta,
          }));
        },
        () => {
          setDownloadState(prev => ({ ...prev, status: 'complete', progress: 100 }));
          // Reset after showing complete
          setTimeout(() => {
            setDownloadState({ status: 'idle', progress: 0, speed: '', eta: '', format: null });
          }, 3000);
        },
        () => {
          setDownloadState(prev => ({ ...prev, status: 'error' }));
        }
      );

      cancelDownloadRef.current = cancel;
    }, 1000);
  }, []);

  const handleCancelDownload = useCallback(() => {
    if (cancelDownloadRef.current) {
      cancelDownloadRef.current();
    }
    setDownloadState({ status: 'idle', progress: 0, speed: '', eta: '', format: null });
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100">
      <Header />
      
      <main className="max-w-4xl mx-auto px-4 pb-16">
        {/* URL Input */}
        <div className="pt-2 pb-8">
          <URLInput onFetch={handleFetch} isLoading={isLoading} />
        </div>

        {/* Error State */}
        {error && !videoInfo && (
          <div className="bg-white rounded-2xl shadow-lg border border-red-100 p-6 text-center animate-fade-in">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-red-50 flex items-center justify-center">
              <svg className="w-8 h-8 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-1">Something went wrong</h3>
            <p className="text-sm text-gray-500">{error}</p>
          </div>
        )}

        {/* Video Info + Download Options */}
        {videoInfo && (
          <div className="space-y-4 animate-fade-in">
            <VideoInfoCard video={videoInfo} />
            
            <DownloadProgress 
              downloadState={downloadState} 
              onCancel={handleCancelDownload} 
            />
            
            <QualityOptions 
              formats={videoInfo.formats} 
              onDownload={handleDownload}
              downloadState={downloadState}
            />
          </div>
        )}

        {/* Features Section - shown when no video is loaded */}
        {!videoInfo && !isLoading && (
          <div className="mt-12 animate-fade-in">
            <h2 className="text-center text-lg font-semibold text-gray-800 mb-6">
              Why use YTGrab?
            </h2>
            <Features />
          </div>
        )}

        {/* How to use section */}
        {!videoInfo && !isLoading && (
          <div className="mt-12 animate-fade-in">
            <h2 className="text-center text-lg font-semibold text-gray-800 mb-6">
              How to download
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {[
                { step: '1', title: 'Paste URL', desc: 'Copy the YouTube video URL and paste it in the input field above.' },
                { step: '2', title: 'Fetch Video', desc: 'Click "Fetch Video" to retrieve video information and available formats.' },
                { step: '3', title: 'Download', desc: 'Choose your preferred quality and format, then click Download.' },
              ].map((item, i) => (
                <div key={i} className="flex items-start gap-3 bg-white rounded-xl p-4 border border-gray-100">
                  <div className="w-8 h-8 rounded-full bg-red-600 text-white flex items-center justify-center font-bold text-sm flex-shrink-0">
                    {item.step}
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 text-sm">{item.title}</h3>
                    <p className="text-xs text-gray-500 mt-0.5">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-gray-200 bg-white/80 backdrop-blur-sm">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <svg className="w-5 h-5 text-red-600" fill="currentColor" viewBox="0 0 24 24">
                <path d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0C.488 3.45.029 5.804 0 12c.029 6.185.484 8.549 4.385 8.816 3.6.245 11.626.246 15.23 0C23.512 20.55 23.971 18.196 24 12c-.029-6.185-.484-8.549-4.385-8.816zM9 16V8l8 4-8 4z"/>
              </svg>
              <span className="text-sm font-semibold text-gray-700">YTGrab</span>
            </div>
            <p className="text-xs text-gray-500 text-center">
              This is a demo interface. No actual downloads are performed.
              <br className="sm:hidden" />
              <span className="hidden sm:inline"> • </span>
              For educational purposes only.
            </p>
            <div className="flex items-center gap-4 text-xs text-gray-400">
              <span>Privacy</span>
              <span>Terms</span>
              <span>Contact</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
