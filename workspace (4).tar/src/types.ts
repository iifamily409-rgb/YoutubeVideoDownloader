export interface VideoFormat {
  itag: number;
  quality: string;
  mimeType: string;
  container: string;
  hasAudio: boolean;
  hasVideo: boolean;
  bitrate?: number;
  audioBitrate?: number;
  label: string;
  fileSize?: string;
}

export interface VideoInfo {
  id: string;
  title: string;
  author: string;
  duration: string;
  durationSeconds: number;
  thumbnail: string;
  viewCount: string;
  publishDate: string;
  formats: VideoFormat[];
}

export type DownloadStatus = 'idle' | 'preparing' | 'downloading' | 'complete' | 'error';

export interface DownloadState {
  status: DownloadStatus;
  progress: number;
  speed: string;
  eta: string;
  format: VideoFormat | null;
}
