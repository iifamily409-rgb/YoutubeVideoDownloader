import { VideoInfo, VideoFormat } from '../types';

const mockVideos: Record<string, VideoInfo> = {
  'dQw4w9WgXcQ': {
    id: 'dQw4w9WgXcQ',
    title: 'Rick Astley - Never Gonna Give You Up (Official Music Video)',
    author: 'Rick Astley',
    duration: '3:33',
    durationSeconds: 213,
    thumbnail: 'https://img.youtube.com/vi/dQw4w9WgXcQ/maxresdefault.jpg',
    viewCount: '1,542,891,234',
    publishDate: 'Oct 25, 2009',
    formats: [],
  },
  'jNQ862KbfSs': {
    id: 'jNQ862KbfSs',
    title: 'Me at the zoo',
    author: 'jawed',
    duration: '0:19',
    durationSeconds: 19,
    thumbnail: 'https://img.youtube.com/vi/jNQ862KbfSs/maxresdefault.jpg',
    viewCount: '298,456,123',
    publishDate: 'Apr 23, 2005',
    formats: [],
  },
};

function generateFormats(videoId: string): VideoFormat[] {
  const formats: VideoFormat[] = [
    // Audio only
    { itag: 140, quality: 'audio', mimeType: 'audio/mp4', container: 'M4A', hasAudio: true, hasVideo: false, audioBitrate: 128, label: 'Audio Only - M4A 128kbps', fileSize: '3.4 MB' },
    { itag: 141, quality: 'audio', mimeType: 'audio/mp4', container: 'M4A', hasAudio: true, hasVideo: false, audioBitrate: 256, label: 'Audio Only - M4A 256kbps', fileSize: '6.8 MB' },
    { itag: 251, quality: 'audio', mimeType: 'audio/webm', container: 'WebM', hasAudio: true, hasVideo: false, audioBitrate: 128, label: 'Audio Only - WebM 128kbps', fileSize: '2.9 MB' },
    { itag: 251, quality: 'audio', mimeType: 'audio/webm', container: 'WebM', hasAudio: true, hasVideo: false, audioBitrate: 192, label: 'Audio Only - WebM 192kbps', fileSize: '4.3 MB' },
    // Video + Audio
    { itag: 18, quality: '360p', mimeType: 'video/mp4', container: 'MP4', hasAudio: true, hasVideo: true, bitrate: 500, label: '360p MP4', fileSize: '12.4 MB' },
    { itag: 22, quality: '720p', mimeType: 'video/mp4', container: 'MP4', hasAudio: true, hasVideo: true, bitrate: 2500, label: '720p MP4', fileSize: '48.2 MB' },
    { itag: 136, quality: '480p', mimeType: 'video/mp4', container: 'MP4', hasAudio: false, hasVideo: true, bitrate: 800, label: '480p MP4 (video only)', fileSize: '18.6 MB' },
    { itag: 137, quality: '1080p', mimeType: 'video/mp4', container: 'MP4', hasAudio: false, hasVideo: true, bitrate: 4500, label: '1080p MP4 (video only)', fileSize: '95.3 MB' },
    { itag: 264, quality: '1440p', mimeType: 'video/mp4', container: 'MP4', hasAudio: false, hasVideo: true, bitrate: 9000, label: '1440p MP4 (video only)', fileSize: '186.7 MB' },
    { itag: 266, quality: '2160p', mimeType: 'video/mp4', container: 'MP4', hasAudio: false, hasVideo: true, bitrate: 18000, label: '2160p 4K MP4 (video only)', fileSize: '378.2 MB' },
    { itag: 248, quality: '1080p', mimeType: 'video/webm', container: 'WebM', hasAudio: false, hasVideo: true, bitrate: 3500, label: '1080p WebM (video only)', fileSize: '72.1 MB' },
    { itag: 271, quality: '1440p', mimeType: 'video/webm', container: 'WebM', hasAudio: false, hasVideo: true, bitrate: 7000, label: '1440p WebM (video only)', fileSize: '142.5 MB' },
    { itag: 313, quality: '2160p', mimeType: 'video/webm', container: 'WebM', hasAudio: false, hasVideo: true, bitrate: 14000, label: '2160p 4K WebM (video only)', fileSize: '289.4 MB' },
  ];

  return formats;
}

export function getMockVideoInfo(videoId: string): VideoInfo | null {
  const baseVideo = mockVideos[videoId];

  if (baseVideo) {
    return { ...baseVideo, formats: generateFormats(videoId) };
  }

  // Generate a generic video for any valid video ID
  return {
    id: videoId,
    title: `YouTube Video (${videoId})`,
    author: 'Unknown Channel',
    duration: '10:24',
    durationSeconds: 624,
    thumbnail: `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`,
    viewCount: `${Math.floor(Math.random() * 10000000).toLocaleString()}`,
    publishDate: 'Jan 1, 2024',
    formats: generateFormats(videoId),
  };
}

export function simulateDownload(
  onProgress: (progress: number, speed: string, eta: string) => void,
  onComplete: () => void,
  onError?: () => void
): () => void {
  let progress = 0;
  let cancelled = false;

  const interval = setInterval(() => {
    if (cancelled) {
      clearInterval(interval);
      return;
    }

    const increment = Math.random() * 8 + 2;
    progress = Math.min(progress + increment, 100);

    const speed = (Math.random() * 5 + 2).toFixed(1) + ' MB/s';
    const remaining = Math.ceil((100 - progress) / increment * 0.5);
    const eta = remaining > 0 ? `${remaining}s` : 'Almost done...';

    onProgress(Math.round(progress), speed, eta);

    if (progress >= 100) {
      clearInterval(interval);
      onComplete();
    }
  }, 500);

  return () => {
    cancelled = true;
    clearInterval(interval);
  };
}
