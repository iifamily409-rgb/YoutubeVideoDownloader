import React, { useState } from 'react';
import { VideoFormat, DownloadState } from '../types';

interface QualityOptionsProps {
  formats: VideoFormat[];
  onDownload: (format: VideoFormat) => void;
  downloadState: DownloadState;
}

type TabType = 'video' | 'audio';

export default function QualityOptions({ formats, onDownload, downloadState }: QualityOptionsProps) {
  const [activeTab, setActiveTab] = useState<TabType>('video');

  const videoFormats = formats.filter(f => f.hasVideo);
  const audioFormats = formats.filter(f => !f.hasVideo && f.hasAudio);

  const getQualityColor = (quality: string) => {
    if (quality.includes('2160') || quality.includes('4K')) return 'bg-purple-100 text-purple-700 border-purple-200';
    if (quality.includes('1440')) return 'bg-blue-100 text-blue-700 border-blue-200';
    if (quality.includes('1080')) return 'bg-green-100 text-green-700 border-green-200';
    if (quality.includes('720')) return 'bg-yellow-100 text-yellow-700 border-yellow-200';
    if (quality.includes('480')) return 'bg-orange-100 text-orange-700 border-orange-200';
    if (quality.includes('360')) return 'bg-gray-100 text-gray-700 border-gray-200';
    return 'bg-gray-100 text-gray-700 border-gray-200';
  };

  const getContainerIcon = (container: string) => {
    switch (container) {
      case 'MP4': return '📦';
      case 'WebM': return '🌐';
      case 'M4A': return '🎵';
      default: return '📄';
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden animate-fade-in">
      {/* Tabs */}
      <div className="flex border-b border-gray-100">
        <button
          onClick={() => setActiveTab('video')}
          className={`flex-1 flex items-center justify-center gap-2 px-4 py-4 text-sm font-semibold transition-all ${
            activeTab === 'video'
              ? 'text-red-600 border-b-2 border-red-600 bg-red-50/50'
              : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
          }`}
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
          </svg>
          Video ({videoFormats.length})
        </button>
        <button
          onClick={() => setActiveTab('audio')}
          className={`flex-1 flex items-center justify-center gap-2 px-4 py-4 text-sm font-semibold transition-all ${
            activeTab === 'audio'
              ? 'text-red-600 border-b-2 border-red-600 bg-red-50/50'
              : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
          }`}
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />
          </svg>
          Audio ({audioFormats.length})
        </button>
      </div>

      {/* Format List */}
      <div className="p-4 max-h-[400px] overflow-y-auto">
        <div className="space-y-2">
          {(activeTab === 'video' ? videoFormats : audioFormats).map((format, index) => {
            const isDownloading = downloadState.status === 'downloading' && downloadState.format === format;
            const isPreparing = downloadState.status === 'preparing' && downloadState.format === format;

            return (
              <div
                key={index}
                className={`flex items-center justify-between p-3 rounded-xl border transition-all hover:shadow-md ${
                  isDownloading || isPreparing
                    ? 'border-red-200 bg-red-50'
                    : 'border-gray-100 hover:border-gray-200 bg-gray-50/50 hover:bg-white'
                }`}
              >
                <div className="flex items-center gap-3 flex-1 min-w-0">
                  <span className="text-lg">{getContainerIcon(format.container)}</span>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-xs font-bold border ${getQualityColor(format.quality)}`}>
                        {format.quality === 'audio' ? 'AUDIO' : format.quality.toUpperCase()}
                      </span>
                      <span className="text-sm font-medium text-gray-800 truncate">
                        {format.label}
                      </span>
                    </div>
                    <div className="flex items-center gap-3 mt-1 text-xs text-gray-500">
                      <span>{format.fileSize}</span>
                      {format.bitrate && <span>• {format.bitrate}kbps</span>}
                      {format.audioBitrate && <span>• {format.audioBitrate}kbps</span>}
                      <span>• {format.container}</span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => onDownload(format)}
                  disabled={downloadState.status === 'downloading' || downloadState.status === 'preparing'}
                  className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-semibold transition-all flex-shrink-0 ml-3 ${
                    isDownloading || isPreparing
                      ? 'bg-red-600 text-white cursor-wait'
                      : 'bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white shadow-sm hover:shadow-md disabled:opacity-50 disabled:cursor-not-allowed'
                  }`}
                >
                  {isPreparing ? (
                    <>
                      <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      <span className="hidden sm:inline">Preparing</span>
                    </>
                  ) : isDownloading ? (
                    <>
                      <svg className="w-4 h-4 animate-pulse" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-11a1 1 0 10-2 0v3.586L7.707 9.293a1 1 0 00-1.414 1.414l3 3a1 1 0 001.414 0l3-3a1 1 0 00-1.414-1.414L11 10.586V7z" clipRule="evenodd"/>
                      </svg>
                      <span className="hidden sm:inline">{downloadState.progress}%</span>
                    </>
                  ) : (
                    <>
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                      </svg>
                      <span className="hidden sm:inline">Download</span>
                    </>
                  )}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Info note */}
      <div className="px-4 pb-4">
        <div className="flex items-start gap-2 p-3 bg-amber-50 border border-amber-100 rounded-xl text-xs text-amber-700">
          <svg className="w-4 h-4 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd"/>
          </svg>
          <span>
            Video-only formats require a separate audio file. Formats labeled "video only" will need ffmpeg to merge with audio.
            Combined formats (360p, 720p MP4) include both video and audio.
          </span>
        </div>
      </div>
    </div>
  );
}
