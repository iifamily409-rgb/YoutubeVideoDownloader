import React from 'react';
import { DownloadState } from '../types';

interface DownloadProgressProps {
  downloadState: DownloadState;
  onCancel: () => void;
}

export default function DownloadProgress({ downloadState, onCancel }: DownloadProgressProps) {
  if (downloadState.status === 'idle' || downloadState.status === 'error') return null;

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-5 animate-fade-in">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          {downloadState.status === 'preparing' && (
            <>
              <div className="w-8 h-8 rounded-full bg-red-100 flex items-center justify-center">
                <svg className="w-4 h-4 text-red-600 animate-spin" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
              </div>
              <div>
                <p className="text-sm font-semibold text-gray-800">Preparing download...</p>
                <p className="text-xs text-gray-500">Extracting stream URLs</p>
              </div>
            </>
          )}
          {downloadState.status === 'downloading' && (
            <>
              <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                <svg className="w-4 h-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                </svg>
              </div>
              <div>
                <p className="text-sm font-semibold text-gray-800">
                  Downloading {downloadState.format?.label}...
                </p>
                <p className="text-xs text-gray-500">{downloadState.speed} • ETA: {downloadState.eta}</p>
              </div>
            </>
          )}
          {downloadState.status === 'complete' && (
            <>
              <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                <svg className="w-4 h-4 text-green-600" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"/>
                </svg>
              </div>
              <div>
                <p className="text-sm font-semibold text-green-700">Download complete!</p>
                <p className="text-xs text-gray-500">{downloadState.format?.label} saved successfully</p>
              </div>
            </>
          )}
        </div>

        {(downloadState.status === 'downloading' || downloadState.status === 'preparing') && (
          <button
            onClick={onCancel}
            className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
            title="Cancel download"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        )}
      </div>

      {/* Progress bar */}
      <div className="relative">
        <div className="w-full h-2.5 bg-gray-100 rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-500 ease-out ${
              downloadState.status === 'complete'
                ? 'bg-gradient-to-r from-green-500 to-green-600'
                : downloadState.status === 'preparing'
                ? 'bg-gradient-to-r from-red-400 to-red-500 animate-pulse'
                : 'bg-gradient-to-r from-red-500 to-red-600'
            }`}
            style={{ width: `${downloadState.progress}%` }}
          />
        </div>
        <div className="flex justify-between mt-1.5">
          <span className="text-xs text-gray-500">
            {downloadState.status === 'preparing' ? 'Connecting...' : `${downloadState.progress}%`}
          </span>
          {downloadState.format && (
            <span className="text-xs text-gray-500">{downloadState.format.fileSize}</span>
          )}
        </div>
      </div>
    </div>
  );
}
